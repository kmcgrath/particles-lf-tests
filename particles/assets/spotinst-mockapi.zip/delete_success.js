module.exports.handler = function(event,context,cb) {
  return cb(null,{statusCode: 200, body: ""});
}
